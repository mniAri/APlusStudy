# A+ Study

A+ Study is a calm AI-powered educational web app concept for students.

## Features
- Study and Decision modes
- Light, Dark and System Default themes
- Very soft pink base with pastel green, blue, purple, pink and yellow accents
- English, Persian, Korean, Chinese, Japanese and Spanish UI
- Image upload and image-generation quota interface
- Responsive chat UI
- Flask backend prepared for secure AI integration

## Run
```bash
python -m venv .venv
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

## Production note
The included AI replies are demo placeholders. For a real public deployment, connect a model through a secure backend and store user quotas in persistent storage. Never expose secret API keys in browser JavaScript.
