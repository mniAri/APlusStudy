from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta, timezone

app = Flask(__name__)
usage = {"uploads": [], "generations": []}
LIMIT = 10

def clean(kind):
    cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
    usage[kind] = [x for x in usage[kind] if x > cutoff]

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/chat")
def chat():
    data = request.get_json() or {}
    mode = data.get("mode", "study")
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"reply": "Tell me what you would like help with, and we’ll take it one step at a time."})
    if mode == "decision":
        reply = ("I’m glad you shared that with me. You don’t have to solve everything at once. "
                 "Let’s slow it down, separate what you can control from what you can’t, "
                 "and choose one small next step. Tell me a little more and I’ll help you think it through without judgment.")
    else:
        reply = ("Absolutely. I can help you understand the topic step by step and adapt the explanation to your level. "
                 "This portfolio build currently uses a demo response; connect a secure server-side AI provider for live model answers.")
    return jsonify({"reply": reply})

@app.post("/api/record")
def record():
    kind = (request.get_json() or {}).get("kind")
    if kind not in usage:
        return jsonify({"error": "invalid"}), 400
    clean(kind)
    if len(usage[kind]) >= LIMIT:
        return jsonify({"error": "cooldown", "remaining": 0}), 429
    usage[kind].append(datetime.now(timezone.utc))
    return jsonify({"ok": True, "remaining": LIMIT-len(usage[kind])})

if __name__ == "__main__":
    app.run(debug=True)
